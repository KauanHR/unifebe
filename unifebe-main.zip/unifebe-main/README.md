# Procedimento

git clone sbaron81/unifebe

./run.sh

docker build -t usuario_github/nome_imagem .

docker run -d -p 5000:5000 -d usuario_github/nome_imagem

http://ip_do_linux:5000

docker login

docker push usuario_github/nome_imagem
